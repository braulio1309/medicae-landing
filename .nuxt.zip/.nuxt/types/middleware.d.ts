import type { NavigationGuard } from 'vue-router'
export type MiddlewareKey = string
declare module "C:/wamp64/www/project/themeforest-gIKNIMVu-veluxi-vue-js-landing-page-collection/veluxi_v312/veluxi/packages/medical-theme/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    middleware?: MiddlewareKey | NavigationGuard | Array<MiddlewareKey | NavigationGuard>
  }
}