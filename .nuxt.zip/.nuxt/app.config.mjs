
import { defuFn } from 'C:/wamp64/www/project/themeforest-gIKNIMVu-veluxi-vue-js-landing-page-collection/veluxi_v312/veluxi/packages/medical-theme/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
